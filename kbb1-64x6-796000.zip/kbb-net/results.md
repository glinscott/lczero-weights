Final results lczero (sha1=089a03d) tc=inf against gnuchess tc=30/1

Steps | Playouts | Rounds | lczero vs gnuchess
------|----------|--------|-------------------
796K  | 40       | 10     | 0 - 9 - 1
296K  | 4000     | 10     | 3 - 6 - 1
796K  | 4000     | 10     | 8 - 1 - 1

